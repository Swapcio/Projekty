package com.example.kalkulator;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText numer1, numer2;
    int num1, num2;
    Button plus_button, subtract_button, multiply_button, devide_button;
    TextView solution;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        devide_button = findViewById(R.id.divide_button);
        multiply_button = findViewById(R.id.multiply_button);
        subtract_button = findViewById(R.id.subtract_button);
        plus_button = findViewById(R.id.plus_button);
        numer1 = findViewById(R.id.numer1);
        numer2 = findViewById(R.id.numer2);
        solution = findViewById(R.id.solution);

        plus_button.setOnClickListener(this);
        subtract_button.setOnClickListener(this);
        multiply_button.setOnClickListener(this);
        devide_button.setOnClickListener(this);


    }

    public int numberFromEdit(EditText editText) {
        if (editText.getText().toString().equals("")) {
            Toast.makeText(this, "Podaj liczbę", Toast.LENGTH_SHORT).show();
            return 0;
        }
        return Integer.parseInt(editText.getText().toString());
    }

    @Override
    public void onClick(View v) {
        num1 = numberFromEdit(numer1);
        num2 = numberFromEdit(numer2);

        if (v.getId() == R.id.plus_button) {
            solution.setText("Wynik = " + (num1 + num2));
        } else if (v.getId() == R.id.subtract_button) {
            solution.setText("Wynik = " + (num1 - num2));
        } else if (v.getId() == R.id.multiply_button) {
            solution.setText("Wynik = " + (num1 * num2));
        } else if (v.getId() == R.id.divide_button) {
            solution.setText("Wynik = " + ((float) num1 / (float) num2));
        } else if (v.getId() == R.id.clear_button) {
            if (v instanceof Button) {
                Button button = (Button) v;
                String buttonText = button.getText().toString();

                if (buttonText.equals("C")) {
                    numer1.setText("");
                    numer2.setText("");
                    solution.setText("");
                } else {
                    String currentText = numer1.getText().toString();
                    currentText += buttonText;
                    numer1.setText(currentText);
                }
            }
        }
    }
}
