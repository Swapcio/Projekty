package com.example.kalkulator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button plus_button, subtract_button, multiply_button, devide_button, equal_button, clear_button;
    Button button0,button1,button2,button3,button4,button5,button6,button7,button8,button9;
    TextView result;
    String operator = "";
    Integer numer1 = 0;
    Integer numer2 = 0;
    Integer equal = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        {
        clear_button = findViewById(R.id.clear_button);
        equal_button = findViewById(R.id.equal_button);
        devide_button = findViewById(R.id.divide_button);
        multiply_button = findViewById(R.id.multiply_button);
        subtract_button = findViewById(R.id.subtract_button);
        plus_button = findViewById(R.id.plus_button);
        result = findViewById(R.id.result);


        plus_button.setOnClickListener(this);
        subtract_button.setOnClickListener(this);
        multiply_button.setOnClickListener(this);
        devide_button.setOnClickListener(this);
        equal_button.setOnClickListener(this);
        clear_button.setOnClickListener(this);

        button0 = findViewById(R.id.button0);
        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);
        button5 = findViewById(R.id.button5);
        button6 = findViewById(R.id.button6);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
        button9 = findViewById(R.id.button9);


            button0.setOnClickListener(this);
            button1.setOnClickListener(this);
            button2.setOnClickListener(this);
            button3.setOnClickListener(this);
            button4.setOnClickListener(this);
            button5.setOnClickListener(this);
            button6.setOnClickListener(this);
            button7.setOnClickListener(this);
            button8.setOnClickListener(this);
            button9.setOnClickListener(this);
        }

    }

@Override
public void onClick(View v) {
    String currentText = result.getText().toString();


    if (v.getId() == R.id.button0) {
        if (currentText.isEmpty()) {

        } else {
            String buttonText = "0";
            result.setText(currentText + buttonText);
        }
    } else if (v.getId() == R.id.button1) {
        String buttonText = "1";
        result.setText(currentText + buttonText);
    } else if (v.getId() == R.id.button2) {
        String buttonText = "2";
        result.setText(currentText + buttonText);
    } else if (v.getId() == R.id.button3) {
        String buttonText = "3";
        result.setText(currentText + buttonText);
    } else if (v.getId() == R.id.button4) {
        String buttonText = "4";
        result.setText(currentText + buttonText);
    } else if (v.getId() == R.id.button5) {
        String buttonText = "5";
        result.setText(currentText + buttonText);
    } else if (v.getId() == R.id.button6) {
        String buttonText = "6";
        result.setText(currentText + buttonText);
    } else if (v.getId() == R.id.button7) {
        String buttonText = "7";
        result.setText(currentText + buttonText);
    } else if (v.getId() == R.id.button8) {
        String buttonText = "8";
        result.setText(currentText + buttonText);
    } else if (v.getId() == R.id.button9) {
        String buttonText = "9";
        result.setText(currentText + buttonText);
    } else if (v.getId() == R.id.plus_button) {
        numer1 = Integer.valueOf(result.getText().toString());
        currentText = "";
        operator = "+";
        result.setText("");
    } else if (v.getId() == R.id.subtract_button) {
        numer1 = Integer.valueOf(result.getText().toString());
        currentText = "";
        operator = "-";
        result.setText("");
    } else if (v.getId() == R.id.multiply_button) {
        numer1 = Integer.valueOf(result.getText().toString());
        currentText = "";
        operator = "*";
        result.setText("");
    } else if (v.getId() == R.id.divide_button) {
        numer1 = Integer.valueOf(result.getText().toString());
        currentText = "";
        operator = "/";
        result.setText("");

    } else if (v.getId() == R.id.equal_button) {

        if(numer1 == null){
            Toast.makeText(this, "Nie można wykonać operacji",Toast.LENGTH_SHORT ).show();
        }else{
            numer2 = Integer.valueOf(result.getText().toString());

            currentText = "";

            if(operator.equals("+")){
                equal = numer1 + numer2;
                Toast.makeText(this, "+",Toast.LENGTH_SHORT ).show();
            } else if (operator.equals("-")) {
                equal = numer1 - numer2;
                Toast.makeText(this, "-",Toast.LENGTH_SHORT ).show();
            } else if (operator.equals("*")) {
                equal = numer1 * numer2;
                Toast.makeText(this, "*",Toast.LENGTH_SHORT ).show();
            } else if (operator.equals("/")) {
                equal = numer1 / numer2;
                Toast.makeText(this, "/",Toast.LENGTH_SHORT ).show();
            } else {
                Toast.makeText(this, "nic",Toast.LENGTH_SHORT ).show();
            }

            Toast.makeText(this, "result",Toast.LENGTH_SHORT ).show();
            result.setText(String.valueOf(equal));
        }
    }
    else if (v.getId() == R.id.clear_button){
        Toast.makeText(this, "c",Toast.LENGTH_SHORT ).show();
        numer1 = 0;
        numer2 = 0;
        operator = "";
        currentText ="";
        result.setText("");

    }
}
    }

